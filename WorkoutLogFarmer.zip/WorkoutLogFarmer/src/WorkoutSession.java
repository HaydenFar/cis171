// Hayden Farmer - Spring 2026

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class WorkoutSession {

    private String sessionId;
    private String date;
    private String notes;
    private List<Exercise> exercises;

    public WorkoutSession(String date, String notes) {
        this.sessionId = UUID.randomUUID().toString();
        this.date = date;
        this.notes = notes;
        this.exercises = new ArrayList<>();
    }

    public WorkoutSession(String sessionId, String date, String notes) {
        this.sessionId = sessionId;
        this.date = date;
        this.notes = notes;
        this.exercises = new ArrayList<>();
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getDate() {
        return date;
    }

    public String getNotes() {
        return notes;
    }

    public List<Exercise> getExercises() {
        return exercises;
    }

    public void addExercise(Exercise exercise) {
        exercises.add(exercise);
    }

    public String toDataString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SESSION|").append(sessionId).append("|").append(date).append("|").append(notes).append("\n");
        for (Exercise e : exercises) {
            sb.append("EXERCISE|").append(sessionId).append("|").append(e.toDataString()).append("\n");
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Session ID: ").append(sessionId).append("\n");
        sb.append("Date: ").append(date).append("\n");
        sb.append("Notes: ").append(notes).append("\n");
        sb.append("Exercises:\n");
        if (exercises.isEmpty()) {
            sb.append("  (No exercises)\n");
        } else {
            for (Exercise e : exercises) {
                sb.append("  - ").append(e.toString()).append("\n");
            }
        }
        return sb.toString();
    }
}
