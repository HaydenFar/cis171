// Hayden Farmer - Spring 2026

public abstract class Exercise {
    private String name;

    public Exercise(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract String getType();

    public abstract String getDetails();

    public abstract String toDataString();

    public static class StrengthExercise extends Exercise {

        private double weight;
        private int sets;
        private int reps;

        public StrengthExercise(String name, double weight, int sets, int reps) {
            super(name);
            this.weight = weight;
            this.sets = sets;
            this.reps = reps;
        }

        public double getWeight() {
            return weight;
        }

        public int getSets() {
            return sets;
        }

        public int getReps() {
            return reps;
        }

        public double getTotalVolume() {
            return weight * sets * reps;
        }

        @Override
        public String getType() {
            return "Strength";
        }

        @Override
        public String getDetails() {
            return String.format("Weight: %.1f lb, Sets: %d, Reps: %d, Volume: %.1f",
                    weight, sets, reps, getTotalVolume());
        }

        @Override
        public String toDataString() {
            return "STRENGTH|" + getName() + "|" + weight + "|" + sets + "|" + reps;
        }

        @Override
        public String toString() {
            return getType() + " - " + getName() + " (" + getDetails() + ")";
        }
    }

    public static class CardioExercise extends Exercise {

        private int durationMinutes;
        private double distanceMiles;

        public CardioExercise(String name, int durationMinutes, double distanceMiles) {
            super(name);
            this.durationMinutes = durationMinutes;
            this.distanceMiles = distanceMiles;
        }

        public int getDurationMinutes() {
            return durationMinutes;
        }

        public double getDistanceMiles() {
            return distanceMiles;
        }

        public double getPaceMinutesPerMile() {
            if (distanceMiles <= 0) {
                return 0.0;
            }
            return durationMinutes / distanceMiles;
        }

        @Override
        public String getType() {
            return "Cardio";
        }

        @Override
        public String getDetails() {
            return String.format("Duration: %d min, Distance: %.2f mi, Pace: %.2f min/mi",
                    durationMinutes, distanceMiles, getPaceMinutesPerMile());
        }

        @Override
        public String toDataString() {
            return "CARDIO|" + getName() + "|" + durationMinutes + "|" + distanceMiles;
        }

        @Override
        public String toString() {
            return getType() + " - " + getName() + " (" + getDetails() + ")";
        }
    }
}
