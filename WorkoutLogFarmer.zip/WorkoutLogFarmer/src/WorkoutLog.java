// Hayden Farmer - Spring 2026

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

public class WorkoutLog {

    private List<WorkoutSession> sessions;

    public WorkoutLog() {
        sessions = new ArrayList<>();
    }

    public void addSession(WorkoutSession session) {
        sessions.add(session);
    }

    public List<WorkoutSession> getSessions() {
        return sessions;
    }

    public WorkoutSession findSessionById(String id) {
        for (WorkoutSession s : sessions) {
            if (s.getSessionId().equals(id)) {
                return s;
            }
        }
        return null;
    }

    public void printAllSessions() {
        if (sessions.isEmpty()) {
            System.out.println("No sessions recorded.");
            return;
        }
        for (WorkoutSession s : sessions) {
            System.out.println("--------------------------------");
            System.out.println(s.toString());
        }
    }

    public void printSessionSummary() {
        if (sessions.isEmpty()) {
            System.out.println("No sessions recorded.");
            return;
        }
        System.out.println("Existing Sessions:");
        for (WorkoutSession s : sessions) {
            System.out.println("ID: " + s.getSessionId() + " | Date: " + s.getDate() + " | Notes: " + s.getNotes());
        }
    }

    public void printStatistics() {
        int totalSessions = sessions.size();
        int totalExercises = 0;
        Map<String, Integer> exerciseCounts = new HashMap<>();

        for (WorkoutSession s : sessions) {
            for (Exercise e : s.getExercises()) {
                totalExercises++;
                String name = e.getName();
                exerciseCounts.put(name, exerciseCounts.getOrDefault(name, 0) + 1);
            }
        }

        System.out.println("\n=== Statistics ===");
        System.out.println("Total sessions: " + totalSessions);
        System.out.println("Total exercises: " + totalExercises);

        if (!exerciseCounts.isEmpty()) {
            String mostCommon = null;
            int maxCount = 0;
            for (Map.Entry<String, Integer> entry : exerciseCounts.entrySet()) {
                if (entry.getValue() > maxCount) {
                    maxCount = entry.getValue();
                    mostCommon = entry.getKey();
                }
            }
            System.out.println("Most common exercise: " + mostCommon + " (" + maxCount + " times)");
        } else {
            System.out.println("No exercises logged yet.");
        }
    }

    public void saveToFile(String filename) {
        try (PrintWriter out = new PrintWriter(filename)) {
            for (WorkoutSession s : sessions) {
                out.print(s.toDataString());
            }
            System.out.println("Workout log saved to " + filename);
        } catch (FileNotFoundException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    public void loadFromFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("No existing data file found. Starting fresh.");
            return;
        }

        Map<String, WorkoutSession> sessionMap = new HashMap<>();
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts[0].equals("SESSION") && parts.length >= 4) {
                    String id = parts[1];
                    String date = parts[2];
                    String notes = parts[3];
                    WorkoutSession session = new WorkoutSession(id, date, notes);
                    sessions.add(session);
                    sessionMap.put(id, session);
                } else if (parts[0].equals("EXERCISE") && parts.length >= 3) {
                    String sessionId = parts[1];
                    WorkoutSession session = sessionMap.get(sessionId);
                    if (session == null) {
                        continue;
                    }
                    String type = parts[2];
                    if ("CARDIO".equals(type) && parts.length >= 6) {
                        String name = parts[3];
                        int duration = Integer.parseInt(parts[4]);
                        double distance = Double.parseDouble(parts[5]);
                        session.addExercise(new Exercise.CardioExercise(name, duration, distance));
                    } else if ("STRENGTH".equals(type) && parts.length >= 7) {
                        String name = parts[3];
                        double weight = Double.parseDouble(parts[4]);
                        int sets = Integer.parseInt(parts[5]);
                        int reps = Integer.parseInt(parts[6]);
                        session.addExercise(new Exercise.StrengthExercise(name, weight, sets, reps));
                    }
                }
            }
            System.out.println("Workout log loaded from " + filename);
        } catch (FileNotFoundException e) {
            System.out.println("Error loading file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Data format error while loading file: " + e.getMessage());
        }
    }
}
