// Hayden Farmer - Spring 2026
// Unit tests for final project

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class WorkoutLogTestsFarmer {

    @Test
    public void testCardioPaceCalculation() {
        Exercise.CardioExercise run = new Exercise.CardioExercise("Running", 30, 3.0);
        Assertions.assertEquals(10.0, run.getPaceMinutesPerMile(), 0.01);
    }

    @Test
    public void testStrengthVolumeCalculation() {
        StrengthExercise squat = new StrengthExercise("Squat", 185.0, 4, 8);
        Assertions.assertEquals(5920.0, squat.getTotalVolume(), 0.01);
    }

    @Test
    public void testWorkoutSessionAddExercise() {
        WorkoutSession session = new WorkoutSession("2026-05-04", "Leg day");
        session.addExercise(new StrengthExercise("Squat", 185, 4, 8));
        session.addExercise(new Exercise.CardioExercise("Bike", 20, 5));

        Assertions.assertEquals(2, session.getExercises().size());
    }

    @Test
    public void testWorkoutLogStatisticsMostCommonExercise() {
        WorkoutLog log = new WorkoutLog();

        WorkoutSession s1 = new WorkoutSession("2026-05-04", "Test");
        s1.addExercise(new StrengthExercise("Bench", 135, 3, 10));
        s1.addExercise(new StrengthExercise("Bench", 135, 3, 10));

        WorkoutSession s2 = new WorkoutSession("2026-05-05", "Test");
        s2.addExercise(new StrengthExercise("Squat", 185, 4, 8));

        log.addSession(s1);
        log.addSession(s2);

        // internal method not exposed, so we check counts manually
        int benchCount = 0;
        int squatCount = 0;

        for (WorkoutSession s : log.getSessions()) {
            for (Exercise e : s.getExercises()) {
                if (e.getName().equals("Bench")) benchCount++;
                if (e.getName().equals("Squat")) squatCount++;
            }
        }

        assertTrue(benchCount > squatCount);
    }

    @Test
    public void testSaveAndLoadFileIntegrity() {
        WorkoutLog log = new WorkoutLog();
        WorkoutSession s = new WorkoutSession("2026-05-04", "Test session");
        s.addExercise(new Exercise.CardioExercise("Run", 20, 2.0));
        log.addSession(s);

        log.saveToFile("test_workoutlog.txt");

        WorkoutLog loaded = new WorkoutLog();
        loaded.loadFromFile("test_workoutlog.txt");

        Assertions.assertEquals(1, loaded.getSessions().size());
        Assertions.assertEquals(1, loaded.getSessions().get(0).getExercises().size());
        Assertions.assertEquals("Run", loaded.getSessions().get(0).getExercises().get(0).getName());
    }
}
