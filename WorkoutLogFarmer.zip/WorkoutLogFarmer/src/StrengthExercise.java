// Hayden Farmer - Spring 2026

public class StrengthExercise extends Exercise {

    private double weight;
    private int sets;
    private int reps;

    public StrengthExercise(String name, double weight, int sets, int reps) {
        super(name);
        this.weight = weight;
        this.sets = sets;
        this.reps = reps;
    }

    public double getWeight() {
        return weight;
    }

    public int getSets() {
        return sets;
    }

    public int getReps() {
        return reps;
    }

    public double getTotalVolume() {
        return weight * sets * reps;
    }

    @Override
    public String getType() {
        return "Strength";
    }

    @Override
    public String getDetails() {
        return String.format("Weight: %.1f lb, Sets: %d, Reps: %d, Volume: %.1f",
                weight, sets, reps, getTotalVolume());
    }

    @Override
    public String toDataString() {
        return "STRENGTH|" + getName() + "|" + weight + "|" + sets + "|" + reps;
    }

    @Override
    public String toString() {
        return getType() + " - " + getName() + " (" + getDetails() + ")";
    }
}
