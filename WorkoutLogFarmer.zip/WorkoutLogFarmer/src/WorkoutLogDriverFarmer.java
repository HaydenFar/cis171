/**
 * Course: CIS171
 * Final Project: Personal Workout Log & Progress Tracker
 * Student: Hayden Farmer
 * Term: Spring 2026
 *
 * Description:
 * This program implements a console-based workout log application.
 * It allows the user to:
 *  - Create workout sessions
 *  - Add cardio and strength exercises
 *  - View all sessions and exercises
 *  - View basic statistics (total sessions, total exercises, most common exercise)
 *  - Save and load data from a text file
 *
 * The project demonstrates:
 *  - Object-oriented design with inheritance (Exercise -> Exercise.CardioExercise/Exercise.StrengthExercise)
 *  - Aggregation (WorkoutSession contains Exercises, WorkoutLog contains Sessions)
 *  - Collections (ArrayList, HashMap)
 *  - File I/O (Scanner, PrintWriter)
 *  - Basic input validation and menu-driven UI
 */

import java.util.Scanner;

public class WorkoutLogDriverFarmer {

    private static final String DATA_FILE = "workoutlog.txt";

    public static void main(String[] args) {
        WorkoutLog log = new WorkoutLog();
        log.loadFromFile(DATA_FILE); // attempt to load existing data

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    createSession(log, scanner);
                    break;
                case "2":
                    addExerciseToSession(log, scanner);
                    break;
                case "3":
                    log.printAllSessions();
                    break;
                case "4":
                    log.printStatistics();
                    break;
                case "5":
                    log.saveToFile(DATA_FILE);
                    System.out.println("Data saved. Exiting program.");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-5.");
            }
        }

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n=== Workout Log Menu ===");
        System.out.println("1. Create new workout session");
        System.out.println("2. Add exercise to existing session");
        System.out.println("3. View all sessions");
        System.out.println("4. View statistics");
        System.out.println("5. Save and Exit");
        System.out.print("Enter choice: ");
    }

    private static void createSession(WorkoutLog log, Scanner scanner) {
        System.out.print("Enter session date (e.g., 2026-05-04): ");
        String date = scanner.nextLine().trim();
        System.out.print("Enter optional notes for this session: ");
        String notes = scanner.nextLine().trim();

        WorkoutSession session = new WorkoutSession(date, notes);
        log.addSession(session);
        System.out.println("Session created with ID: " + session.getSessionId());
    }

    private static void addExerciseToSession(WorkoutLog log, Scanner scanner) {
        if (log.getSessions().isEmpty()) {
            System.out.println("No sessions available. Create a session first.");
            return;
        }

        log.printSessionSummary();
        System.out.print("Enter session ID to add exercise to: ");
        String idStr = scanner.nextLine().trim();

        WorkoutSession session = log.findSessionById(idStr);
        if (session == null) {
            System.out.println("Session not found.");
            return;
        }

        System.out.println("Add Exercise Type:");
        System.out.println("1. Cardio");
        System.out.println("2. Strength");
        System.out.print("Enter choice: ");
        String typeChoice = scanner.nextLine().trim();

        System.out.print("Enter exercise name: ");
        String name = scanner.nextLine().trim();

        if ("1".equals(typeChoice)) {
            System.out.print("Enter duration in minutes: ");
            int minutes = parseIntSafe(scanner.nextLine().trim(), 0);
            System.out.print("Enter distance in miles: ");
            double miles = parseDoubleSafe(scanner.nextLine().trim(), 0.0);

            Exercise.CardioExercise cardio = new Exercise.CardioExercise(name, minutes, miles);
            session.addExercise(cardio);
            System.out.println("Cardio exercise added.");
        } else if ("2".equals(typeChoice)) {
            System.out.print("Enter weight in pounds: ");
            double weight = parseDoubleSafe(scanner.nextLine().trim(), 0.0);
            System.out.print("Enter number of sets: ");
            int sets = parseIntSafe(scanner.nextLine().trim(), 0);
            System.out.print("Enter number of reps per set: ");
            int reps = parseIntSafe(scanner.nextLine().trim(), 0);

            Exercise.StrengthExercise strength = new Exercise.StrengthExercise(name, weight, sets, reps);
            session.addExercise(strength);
            System.out.println("Strength exercise added.");
        } else {
            System.out.println("Invalid exercise type.");
        }
    }

    private static int parseIntSafe(String input, int defaultValue) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    private static double parseDoubleSafe(String input, double defaultValue) {
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }
}
